export default function NOOP() {} // eslint-disable-line @typescript-eslint/no-empty-function
