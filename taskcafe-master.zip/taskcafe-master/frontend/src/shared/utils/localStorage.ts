const localStorage = {
  NOTIFICATIONS_FILTER: 'notifications_filter',
  CARD_LABEL_VARIANT_STORAGE_KEY: 'card_label_variant',
};

export default localStorage;
