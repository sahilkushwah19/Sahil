import React from 'react';
import styled from 'styled-components';

const Tabs = () => {
  return <span>HEllo!</span>;
};

export default Tabs;
