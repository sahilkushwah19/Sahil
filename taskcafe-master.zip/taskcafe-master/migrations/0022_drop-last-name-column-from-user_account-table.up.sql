ALTER TABLE user_account DROP COLUMN last_name;
