INSERT INTO user_account(created_at, email, initials, username, full_name,
  role_code, password_hash) VALUES (NOW(), '', 'SYS', 'system', 'System', 'owner', '');
