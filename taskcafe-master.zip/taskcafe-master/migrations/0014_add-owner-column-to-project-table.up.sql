ALTER TABLE project ADD COLUMN owner uuid NOT NULL;
