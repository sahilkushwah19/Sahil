ALTER TABLE project_member ADD UNIQUE (project_id, user_id);
