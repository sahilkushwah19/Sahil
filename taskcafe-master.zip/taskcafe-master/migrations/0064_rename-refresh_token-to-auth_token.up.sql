ALTER TABLE refresh_token RENAME TO auth_token;
