ALTER TABLE user_account ADD COLUMN profile_avatar_url TEXT;
