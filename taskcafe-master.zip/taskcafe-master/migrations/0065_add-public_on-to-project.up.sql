ALTER TABLE project ADD COLUMN public_on timestamptz;
