package utils

type NotificationCreatedMessage struct {
	NotifiedID     string
	NotificationID string
}
